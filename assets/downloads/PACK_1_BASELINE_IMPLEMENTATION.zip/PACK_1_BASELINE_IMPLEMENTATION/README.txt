PACK 1 — BASELINE IMPLEMENTATION BUNDLE (v1.0)

This ZIP contains baseline materials to support implementation of the Child Mode Declaration Standard.

Files:
- PACK_1_BASELINE_IMPLEMENTATION.pdf  (printable pack)
- AI_Child_Mode_Safety_Guide_v3_4_SCHOOL_LAYOUT_ACTIVATION.pdf (reference guide, if included)
- README.txt

Official reference (canonical declaration):
https://youandai.you/signature/child

Note: Pack 1 does not supervise use. Adult supervision remains required.
