PACK 1 — BASELINE IMPLEMENTATION (v1.1)

EN declaration: https://youandai.you/signature/child/
ES declaration: https://youandai.you/signature/child/es/

Non-override (practical): if behaviour deviates, stop and restart with a fresh declaration.
